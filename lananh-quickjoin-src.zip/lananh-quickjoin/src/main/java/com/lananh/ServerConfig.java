package com.lananh;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class ServerConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static List<ServerEntry> servers = new ArrayList<>();

    private ServerConfig() {}

    public static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("lananh_servers.json");
    }

    public static List<ServerEntry> get() {
        if (servers.isEmpty()) load();
        return servers;
    }

    public static void load() {
        Path p = path();
        try {
            if (!Files.exists(p)) {
                servers = defaults();
                Files.writeString(p, GSON.toJson(servers));
                return;
            }
            ServerEntry[] arr = GSON.fromJson(Files.readString(p), ServerEntry[].class);
            servers = (arr == null || arr.length == 0) ? defaults() : new ArrayList<>(Arrays.asList(arr));
        } catch (Exception e) {
            servers = defaults();
        }
    }

    // SUA IP o day hoac trong config/lananh_servers.json
    private static List<ServerEntry> defaults() {
        List<ServerEntry> l = new ArrayList<>();
        l.add(new ServerEntry("Crystal PvP", "crystal.example.net", "end_crystal",
                "Server PvP crystal", List.of("crystal", "pha le", "pvp", "crystal pvp")));
        l.add(new ServerEntry("Sword PvP", "sword.example.net", "netherite_sword",
                "Server PvP kiem", List.of("sword", "kiem", "pvp", "duel", "1v1")));
        l.add(new ServerEntry("Survival", "survival.example.net", "dirt",
                "Sinh ton", List.of("survival", "sinh ton", "dat", "dirt", "smp")));
        l.add(new ServerEntry("Mace PvP", "mace.example.net", "mace",
                "Server PvP bua mace", List.of("mace", "bua", "pvp", "mace pvp")));
        l.add(new ServerEntry("Skyblock", "skyblock.example.net", "grass_block",
                "Dao tren troi", List.of("skyblock", "dao", "sky")));
        l.add(new ServerEntry("Lifesteal", "lifesteal.example.net", "totem_of_undying",
                "Lifesteal SMP", List.of("lifesteal", "hut mau", "tim", "heart")));
        return l;
    }
}
