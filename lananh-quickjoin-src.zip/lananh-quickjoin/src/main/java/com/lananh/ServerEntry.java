package com.lananh;

import java.util.List;

public class ServerEntry {
    public String name;
    public String ip;
    public String item;       // vd: "end_crystal", "netherite_sword", "dirt", "mace"
    public String desc;
    public List<String> tags; // tu khoa (co the tieng Viet)

    public ServerEntry(String name, String ip, String item, String desc, List<String> tags) {
        this.name = name;
        this.ip = ip;
        this.item = item;
        this.desc = desc;
        this.tags = tags;
    }
}
