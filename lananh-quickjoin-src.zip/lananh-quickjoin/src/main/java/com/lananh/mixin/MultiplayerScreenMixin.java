package com.lananh.mixin;

import com.lananh.QuickJoinScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MultiplayerScreen.class)
public abstract class MultiplayerScreenMixin extends Screen {
    protected MultiplayerScreenMixin(Text title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void lananh$addQuickJoin(CallbackInfo ci) {
        addDrawableChild(ButtonWidget.builder(Text.literal("§dGia nhập nhanh"),
                        b -> this.client.setScreen(new QuickJoinScreen(this)))
                .dimensions(5, 5, 110, 20).build());
    }
}
