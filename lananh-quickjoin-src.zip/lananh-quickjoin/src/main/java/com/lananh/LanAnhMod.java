package com.lananh;

import net.fabricmc.api.ClientModInitializer;

public class LanAnhMod implements ClientModInitializer {
    public static final String ID = "lananh";

    @Override
    public void onInitializeClient() {
        ServerConfig.load();
    }
}
