package com.lananh;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuickJoinScreen extends Screen {
    private static final int CELL = 64;

    private final Screen parent;
    private List<ServerEntry> servers;
    private final Map<ServerEntry, ItemStack> stacks = new HashMap<>();
    private TextFieldWidget input;
    private String reply = "Xin chào, Lan Anh Kaiwai đây~ Bạn muốn vào server gì? (vd: \"crystal pvp\", \"sinh tồn\", \"búa mace\")";
    private ServerEntry highlighted;
    private ServerEntry pending;
    private int pendingTicks;

    public QuickJoinScreen(Screen parent) {
        super(Text.literal("Gia nhập nhanh"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        ServerConfig.load();
        servers = ServerConfig.get();
        stacks.clear();
        for (ServerEntry s : servers) {
            Item item = Items.BARRIER;
            try {
                Identifier id = Identifier.tryParse(s.item.contains(":") ? s.item : "minecraft:" + s.item);
                if (id != null && Registries.ITEM.containsId(id)) item = Registries.ITEM.get(id);
            } catch (Exception ignored) {}
            stacks.put(s, new ItemStack(item));
        }

        input = new TextFieldWidget(textRenderer, width / 2 - 150, height - 60, 240, 20, Text.literal("Lan Anh"));
        input.setMaxLength(200);
        input.setPlaceholder(Text.literal("Nói Lan Anh biết bạn muốn server gì..."));
        addDrawableChild(input);
        setInitialFocus(input);

        addDrawableChild(ButtonWidget.builder(Text.literal("Gửi"), b -> submit())
                .dimensions(width / 2 + 95, height - 60, 55, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Quay lại"), b -> close())
                .dimensions(width / 2 - 50, height - 32, 100, 20).build());
    }

    private int cols() {
        return Math.max(1, Math.min(servers.size(), (width - 40) / CELL));
    }

    private int startX() {
        return (width - cols() * CELL) / 2;
    }

    private static final int START_Y = 40;

    private void submit() {
        String q = input.getText();
        if (q.isBlank()) return;
        LanAnhBrain.Result r = LanAnhBrain.think(q, servers);
        reply = r.message();
        highlighted = r.pick();
        pending = r.pick();
        pendingTicks = 40;
        input.setText("");
    }

    private void join(ServerEntry e) {
        if (client == null) return;
        ServerAddress addr = ServerAddress.parse(e.ip);
        ServerInfo info = new ServerInfo(e.name, e.ip, ServerInfo.ServerType.OTHER);
        ConnectScreen.connect(this, client, addr, info, false, null);
    }

    @Override
    public void tick() {
        super.tick();
        if (pending != null && --pendingTicks <= 0) {
            ServerEntry e = pending;
            pending = null;
            join(e);
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256 && pending != null) { // ESC huy
            pending = null;
            reply = "Ok Lan Anh hủy rồi nha~";
            return true;
        }
        if ((keyCode == 257 || keyCode == 335) && input.isFocused()) {
            submit();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        ServerEntry hit = entryAt((int) mx, (int) my);
        if (hit != null && button == 0) {
            pending = null;
            join(hit);
            return true;
        }
        return false;
    }

    private ServerEntry entryAt(int mx, int my) {
        int cols = cols();
        for (int i = 0; i < servers.size(); i++) {
            int x = startX() + (i % cols) * CELL;
            int y = START_Y + (i / cols) * (CELL + 14);
            if (mx >= x && mx < x + CELL - 4 && my >= y && my < y + CELL + 8) return servers.get(i);
        }
        return null;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§6Gia nhập nhanh §7- chọn item để vào server"), width / 2, 14, 0xFFFFFF);

        int cols = cols();
        ServerEntry hover = entryAt(mouseX, mouseY);
        for (int i = 0; i < servers.size(); i++) {
            ServerEntry s = servers.get(i);
            int x = startX() + (i % cols) * CELL;
            int y = START_Y + (i / cols) * (CELL + 14);

            ctx.fill(x, y, x + CELL - 4, y + CELL + 8, s == hover ? 0x90FFFFFF : 0x60000000);
            if (s == highlighted) ctx.drawBorder(x, y, CELL - 4, CELL + 8, 0xFFFFAA00);

            var m = ctx.getMatrices();
            m.push();
            m.translate(x + (CELL - 4 - 32) / 2f, y + 8, 0);
            m.scale(2f, 2f, 1f);
            ctx.drawItem(stacks.get(s), 0, 0);
            m.pop();

            String nm = textRenderer.trimToWidth(s.name, CELL - 8);
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(nm), x + (CELL - 4) / 2, y + 46, 0xFFFFFF);
            String ip = textRenderer.trimToWidth(s.ip, CELL - 8);
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§7" + ip), x + (CELL - 4) / 2, y + 58, 0xAAAAAA);
        }

        // khung chat Lan Anh
        int bx = width / 2 - 150;
        int by = height - 60 - 52;
        ctx.fill(bx, by, bx + 300, by + 46, 0xA0000000);
        ctx.drawBorder(bx, by, 300, 46, 0xFFFF77AA);
        ctx.drawTextWithShadow(textRenderer, Text.literal("§dLan Anh Kaiwai"), bx + 4, by + 3, 0xFFFFFF);
        int ty = by + 14;
        for (OrderedText line : textRenderer.wrapLines(Text.literal(reply), 292)) {
            if (ty > by + 36) break;
            ctx.drawTextWithShadow(textRenderer, line, bx + 4, ty, 0xFFFFFF);
            ty += 10;
        }

        if (pending != null) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("§eĐang vào " + pending.name + " ... (" + (pendingTicks / 20 + 1) + "s)"), width / 2, by - 12, 0xFFFFFF);
        }
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }
}
