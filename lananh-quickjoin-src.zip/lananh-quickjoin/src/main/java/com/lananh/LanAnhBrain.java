package com.lananh;

import java.text.Normalizer;
import java.util.*;

/** "Bo nao" cua Lan Anh: hieu tieng Viet (co dau / khong dau), chon server phu hop. Chay offline. */
public final class LanAnhBrain {
    public record Result(ServerEntry pick, String message) {}

    private static final Random RNG = new Random();

    // cum tu nhieu chu -> tu khoa chuan
    private static final String[][] PHRASES = {
            {"sinh ton", "survival"}, {"pha le", "crystal"}, {"hut mau", "lifesteal"},
            {"tren troi", "skyblock"}, {"xay dung", "build"}, {"choi 1v1", "duel"}
    };
    // tu don -> tu khoa chuan
    private static final Map<String, String> WORDS = Map.ofEntries(
            Map.entry("kiem", "sword"), Map.entry("dat", "dirt"), Map.entry("bua", "mace"),
            Map.entry("kristal", "crystal"), Map.entry("crytal", "crystal"), Map.entry("cristal", "crystal"),
            Map.entry("sv", "server"), Map.entry("may", "server"), Map.entry("dao", "skyblock"),
            Map.entry("danh", "pvp"), Map.entry("pk", "pvp"), Map.entry("chien", "pvp")
    );
    private static final Set<String> STOP = Set.of("toi", "tui", "muon", "vao", "choi", "tim", "cho", "di", "la",
            "nha", "nhe", "oi", "giup", "voi", "co", "khong", "the", "mot", "cai", "server", "lan", "anh", "ban",
            "mo", "vo", "kiem", "gi", "nao", "den", "chon", "dum", "ho", "minh");

    private LanAnhBrain() {}

    public static String normalize(String s) {
        String n = Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        n = n.replaceAll("\\p{M}+", "").replace('đ', 'd');
        return n.replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
    }

    public static Result think(String query, List<ServerEntry> servers) {
        String q = normalize(query);
        if (q.isEmpty()) return new Result(null, "Lan Anh đang nghe nè, bạn muốn vào server gì~");

        for (String[] p : PHRASES) q = q.replace(p[0], p[1]);

        List<String> tokens = new ArrayList<>();
        for (String t : q.split(" ")) {
            String m = WORDS.getOrDefault(t, t);
            if (m.length() >= 2 && !(STOP.contains(t) && !WORDS.containsKey(t))) tokens.add(m);
        }

        Map<ServerEntry, Integer> score = new LinkedHashMap<>();
        for (ServerEntry s : servers) {
            int sc = 0;
            String name = normalize(s.name == null ? "" : s.name);
            String desc = normalize(s.desc == null ? "" : s.desc);
            String item = normalize(s.item == null ? "" : s.item.replace('_', ' '));
            List<String> tags = new ArrayList<>();
            if (s.tags != null) for (String t : s.tags) {
                String nt = normalize(t);
                for (String[] p : PHRASES) nt = nt.replace(p[0], p[1]);
                tags.add(WORDS.getOrDefault(nt, nt));
            }
            for (String t : tokens) {
                for (String tag : tags) {
                    if (tag.equals(t)) sc += 4;
                    else if (tag.length() >= 3 && t.length() >= 3 && (tag.contains(t) || t.contains(tag))) sc += 2;
                }
                if (name.contains(t)) sc += 3;
                if (item.contains(t)) sc += 2;
                if (desc.contains(t)) sc += 1;
            }
            if (sc > 0) score.put(s, sc);
        }

        if (score.isEmpty()) {
            if (q.matches(".*\\b(hi|hello|chao|xin chao|alo)\\b.*"))
                return new Result(null, "Chào bạn! Lan Anh đây~ Bạn muốn chơi server gì? Ví dụ: \"crystal pvp\", \"sinh tồn\", \"mace\".");
            Set<String> hints = new LinkedHashSet<>();
            for (ServerEntry s : servers) if (s.tags != null && !s.tags.isEmpty()) hints.add(s.tags.get(0));
            return new Result(null, "Lan Anh chưa hiểu bạn muốn server nào 🥺 Thử gõ: " + String.join(", ", hints));
        }

        List<Map.Entry<ServerEntry, Integer>> sorted = new ArrayList<>(score.entrySet());
        sorted.sort((a, b) -> b.getValue() - a.getValue());
        ServerEntry best = sorted.get(0).getKey();

        String[] ok = {
                "Lan Anh chọn %s cho bạn nè~ Vào luôn nha!",
                "Đúng gu bạn rồi, mình vào %s thôi!",
                "Tìm thấy %s rồi, Lan Anh dẫn bạn đi nè~",
                "%s hợp với bạn đó, đi thôi!"
        };
        StringBuilder msg = new StringBuilder(String.format(ok[RNG.nextInt(ok.length)], best.name));
        if (sorted.size() > 1) {
            msg.append(" (Còn: ");
            for (int i = 1; i < Math.min(sorted.size(), 3); i++) {
                if (i > 1) msg.append(", ");
                msg.append(sorted.get(i).getKey().name);
            }
            msg.append(")");
        }
        msg.append("\nBấm ESC để hủy.");
        return new Result(best, msg.toString());
    }
}
